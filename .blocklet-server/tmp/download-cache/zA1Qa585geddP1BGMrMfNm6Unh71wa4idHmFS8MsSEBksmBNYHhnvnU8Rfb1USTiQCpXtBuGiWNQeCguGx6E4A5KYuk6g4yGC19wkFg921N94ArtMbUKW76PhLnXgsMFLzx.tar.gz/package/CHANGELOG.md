## 2.0.56 (July 13, 2024)

- fix: component call - label action logs

## 2.0.55 (July 12, 2024)

- chore(discussion): layout improvements

## 2.0.54 (July 12, 2024)

- fix(discussion): fix scrolling issue in safari(#2427)

## 2.0.53 (July 12, 2024)

- fix(lint): fix lint error
- chore(discuss-kit): profile page support did params in url
- chore(deps): update deps

## 2.0.52 (July 12, 2024)

- feat: improve message

## 2.0.51 (July 11, 2024)

- feat: improve message

## 2.0.50 (July 10, 2024)

- chore: discussion menu adjustment

## 2.0.49 (July 10, 2024)

- feat: support discussion creation with markdown content via url params
- fix: #2668

## 2.0.48 (July 09, 2024)

- fix(comments): properly render nested comments (#2663)
- fix: prioritize unauthenticated error over unauthorized error(#2174)

## 2.0.47 (July 09, 2024)

- feat: support donation in comments

## 2.0.45 (July 08, 2024)

- fix(comments): improve error handling for unavailable discuss-kit

## 2.0.44 (July 08, 2024)

- fix: comment action log now working
- fix: label action log not working when component call

## 2.0.43 (July 05, 2024)

- feat: add post-actions support

## 2.0.42 (July 05, 2024)

- fix: relative time i18n

## 2.0.41 (July 05, 2024)

- feat: update action log icon

## 2.0.40 (July 04, 2024)

- fix: docs board change log not working & log i18n issue

## 2.0.39 (July 04, 2024)

- chore: improve post search API error handling for unavailable meilisearch

## 2.0.38 (July 04, 2024)

- feat: add API call to search posts
- fix: #2503

## 2.0.37 (July 04, 2024)

- fix(comments): add error handling for unavailable API

## 2.0.36 (July 04, 2024)

- fix: backlink not working in replies

## 2.0.35 (July 03, 2024)

- feat: add user action log part 5

## 2.0.34 (July 03, 2024)

- feat: add user action log part 4

## 2.0.33 (July 02, 2024)

- feat: add user action log part 3

## 2.0.32 (June 28, 2024)

- fix: null pointer issue

## 2.0.31 (June 28, 2024)

- fix: remove unused variant

## 2.0.30 (June 28, 2024)

- feat: add user action log part 2

## 2.0.29 (June 26, 2024)

- refactor: add initProxyToMediaKitUploadsMiddleware to view Media Kit assets

## 2.0.28 (June 26, 2024)

- fix: fix issue with updating post labels in discussion edit settings

## 2.0.27 (June 25, 2024)

- chore: use createAxios from @blocklet/js-sdk instead of axios
- fix: #2586
- fix: #2592
- fix: #2595

## 2.0.26 (June 24, 2024)

- chore: add disableActionLog prefs option to allow disabling action log

## 2.0.25 (June 24, 2024)

- chore: update deps

## 2.0.24 (June 21, 2024)

- feat: add user action log

## 2.0.23 (June 20, 2024)

- chore: remove user-scalable meta tag for accessibility improvement
- chore(chat-in-wallet): update avatar URL to absolute path

## 2.0.22 (June 20, 2024)

- chore(chat-in-wallet): add chatUrl to notification message

## 2.0.21 (June 20, 2024)

- fix(api): resource blocklet broken on isolation mode

## 2.0.20 (June 19, 2024)

- fix(editor): add safe area handling to ai/image to avoid overflow
- fix: check permissions before updating post labels
- refactor: post assignment improvements/refactorings
- fix: #2514
- fix: #1279
- fix: #2560

## 2.0.19 (June 19, 2024)

- chore: bump deps to latest
- chore: use puppeteer fork to make things work in isolation mode
- fix: use blocklet data dir for puppeteer related config

## 2.0.18 (June 18, 2024)

- feat: add 'pinned' tab to discussion list page
- chore: improve responsiveness of editor floating toolbar(#2556)
- feat: support URL param-based prefilling when creating new discussions
- fix: add 'task' type notification support(#2539)
- fix: #2557

## 2.0.17 (June 18, 2024)

- fix: comment count issue

## 2.0.16 (June 18, 2024)

- fix: `ContainerWithDrawer` mobile style issue

## 2.0.15 (June 17, 2024)

- feat: add drawer close button for blog, docs and discussion

## 2.0.14 (June 13, 2024)

- chore: update deps

## 2.0.13 (June 13, 2024)

- chore(post-search): filter out invalid labels to improve security
- feat: support transfering post content through SessionStorage

## 2.0.12 (June 13, 2024)

- feat(api): support batch updating of labels for multiple posts

## 2.0.11 (June 12, 2024)

- chore: update deps

## 2.0.10 (June 12, 2024)

- fix: treat boards with empty type as discussion boards(#2533)
- chore: update deps

## 2.0.9 (June 11, 2024)

- feat(editor): add markdown-editor component

## 2.0.7 (June 07, 2024)

- fix: fix the issue of assignees disappearing after label changes

## 2.0.6 (June 07, 2024)

- feat: allow users to modify default board
- refactor: add API endpoints for adding/removing labels to posts
- chore: disable editor EquationsPlugin
- chore(editor): reorder buttons in editor toolbar
- fix: #2505

## 2.0.5 (June 06, 2024)

- chore(chat-in-wallet): open profile in new tab when avatar is clicked
- chore: disable avatar hover effect in mobile
- fix(chat-in-wallet): ensure all links open in new tab forcibly
- fix: improve enter key shortcut logic for chat-input
- chore: improve message input cleanup logic after sending
- feat(chat): improve chat-input & support editor minimalMode
- chore: display author and last edit time for doc posts
- feat(chat-input): add swipe detection to blur editor on mobile

## 2.0.3 (June 05, 2024)

- chore: chat-in-wallet improvements

## 2.0.2 (June 04, 2024)

- chore: add chat-input component & chat-related improvements
- chore: update discussion stats call api to include post ids

## 2.0.1 (June 03, 2024)

- chore: order assigned posts by creation date

## 2.0.0 (June 01, 2024)

- v2.0.0 released!
- fix: translation failure when mountpoint is '/'
- fix(meilisearch): prevent redundant updateIndexes on startup

## 1.6.264 (May 30, 2024)

- chore: refactor discussion stats api to include countsByAuthor

## 1.6.263 (May 29, 2024)

- chore: add '/api/call/discussions/stats/users' api
- chore: improve discussions stats api
- chore: polish label management page

## 1.6.262 (May 28, 2024)

- chore(editor): reduce paragraph spacing(#2284)

## 1.6.261 (May 28, 2024)

- fix(chat-in-wallet): fix infinite loading issue(#2501)
- feat: add `/api/call/discussions/stats` api

## 1.6.260 (May 27, 2024)

- fix(editor): fix incorrect stroke-width of image markers after scaling
- chore(chat-in-wallet): use appPid instead of appId in updateUnreadState

## 1.6.259 (May 27, 2024)

- fix(editor): improvements to image editing on mobile(#2493)

## 1.6.258 (May 24, 2024)

- feat(editor): support frame mockups for images
- chore: add a new 'chatEnabled' flag to blocklet prefs
- chore(post-package): allow loading post by id or slug

## 1.6.257 (May 22, 2024)

- chore(chat-in-wallet): improve updateUnreadState logic

## 1.6.256 (May 21, 2024)

- chore(editor): improve images display with responsive width

## 1.6.255 (May 21, 2024)

- chore(blog): layout improvements for better readability

## 1.6.254 (May 21, 2024)

- feat: add @blocklet/discuss-kit-post package & Post component
- chore(chat-in-wallet): sync unread status with wallet at startup
- chore: update ux/rollup-plugin-node-externals & vite config tweaks

## 1.6.253 (May 20, 2024)

- fix(discussion): improve publish logic to avoid duplicate post creation

## 1.6.252 (May 19, 2024)

- chore(chat-in-wallet): update wallet used for compatibility check

## 1.6.251 (May 18, 2024)

- chore(doc): relocate comment section from sidebar to page bottom

## 1.6.250 (May 18, 2024)

- fix(chat-in-wallet): adjust chat page to display at full height

## 1.6.249 (May 18, 2024)

- refactor(chat-in-wallet): improve page transition & routing logic

## 1.6.248 (May 17, 2024)

- chore: polish popop close error
- feat(editor): add image marker support and improve image size handling

## 1.6.247 (May 16, 2024)

- fix: fix labels display issue on blog page

## 1.6.246 (May 16, 2024)

- chore(chat-in-wallet): add window.navigateToChatList api

## 1.6.245 (May 15, 2024)

- chore(chat-in-wallet): polish chat page

## 1.6.244 (May 15, 2024)

- chore: preload editor to speed up loading of chat page
- chore(wallet-in-chat): improve chat navigation logic

## 1.6.243 (May 14, 2024)

- chore: improve layout on post edit page
- chore: avoid sending notifications to followers when comment/reply
- chore: only admins can create labels

## 1.6.242 (May 13, 2024)

- fix(editor): improve AI availability check logic
- chore(editor): improve checklist item indentation

## 1.6.241 (May 11, 2024)

- chore: ui improvements

## 1.6.240 (May 10, 2024)

- chore(editor): improve list item indentation

## 1.6.239 (May 10, 2024)

- chore: improvements to discussion list page(#2310)
- fix misleading wording & introduce "cc" in comment/reply notifications
- fix: #2436, #2431, #2425, #2123
- fix: make twitter embed width responsive
- chore(chat): display profile and badge on avatar hover
- chore: disable notification for open/close events

## 1.6.238 (May 09, 2024)

- fix: improve back button behavior with location state(#2414,#1010,#770)

## 1.6.237 (May 08, 2024)

- chore: polish FilePlugin style
- feat: add wide content width option to doc settings

## 1.6.236 (May 08, 2024)

- ci: fix build error

## 1.6.235 (May 08, 2024)

- feat: adjust new uploader and add file plugin

## 1.6.234 (May 08, 2024)

- feat(editor): add support for pages-kit custom components
- fix: #2356

## 1.6.233 (May 06, 2024)

- fix(discussion): restrict pin/feature post ability to admins only
- fix: #2380

## 1.6.232 (May 03, 2024)

- fix: fix permission error when update discussion board
- chore: polish label styles
- fix: #2406

## 1.6.231 (April 30, 2024)

- chore: polish label styles

## 1.6.230 (April 29, 2024)

- chore: polish @blocklet/crawler redis key logic

## 1.6.229 (April 29, 2024)

- fix: post favoriting improvements
- fix: fix incorrect appUrl(#2390)

## 1.6.228 (April 29, 2024)

- fix(label-picker): improve recent label tracking/display
- chore: update deps

## 1.6.227 (April 25, 2024)

- fix(chat): improve reliability of websocket connections(#1877)
- fix: #2373

## 1.6.226 (April 24, 2024)

- chore: polish blog detail page

## 1.6.225 (April 24, 2024)

- fix(chat): improve chat input rendering & fix menu dismissal issue
- fix: fix navigation issue when discussions are saved

## 1.6.224 (April 24, 2024)

- fix(chat-in-wallet): chat notification bug

## 1.6.223 (April 23, 2024)

- feat: support chat in wallet

## 1.6.222 (April 23, 2024)

- ci: fix build error

## 1.6.221 (April 23, 2024)

- feat: discussion editing improvements
- feat: add discussion report support(#2334)
- fix: #2369

## 1.6.220 (April 22, 2024)

- fix: improve translation prompt

## 1.6.219 (April 19, 2024)

- chore: update deps

## 1.6.218 (April 19, 2024)

- chore: adjust background color on doc page

## 1.6.217 (April 17, 2024)

- feat: allow enable/disable specific features(blog, bookmark, etc.)
- fix: improve banner/hero display on docs home page(#2342)
- fix: #2340, #1529

## 1.6.216 (April 16, 2024)

- chore: update deps

## 1.6.215 (April 16, 2024)

- chore: add '/sql/scripts' api

## 1.6.214 (April 15, 2024)

- chore: add '/call/boards' api

## 1.6.213 (April 12, 2024)

- fix: improve mui theme and dialog styles

## 1.6.212 (April 11, 2024)

- feat: add discussion donation support

## 1.6.211 (April 11, 2024)

- chore: add bookmark pageGroup

## 1.6.210 (April 10, 2024)

- chore: polish resource pack export logic

## 1.6.209 (April 10, 2024)

- chore: polish resource pack duplicate boards and labels logic

## 1.6.208 (April 10, 2024)

- fix: polish resource pack init data logic

## 1.6.207 (April 10, 2024)

- fix: polish useBoards refresh logic
- chore: reduce stroke width of tabler icons
- chore: improve labels-picker component

## 1.6.206 (April 09, 2024)

- chore: move all providers into RouterProvider

## 1.6.205 (April 08, 2024)

- chore: polish dsbridge source

## 1.6.204 (April 08, 2024)

- fix: polish component picker plugin error logic

## 1.6.203 (April 08, 2024)

- fix: board select bug on discussion page
- fix: translate listener bug
- feat: support discussionsVisiblePostTypes in prefs

## 1.6.202 (April 07, 2024)

- fix: polish bookmark close dialog error logic

## 1.6.201 (April 07, 2024)

- chore: update deps

## 1.6.200 (April 07, 2024)

- fix: translation-related improvements

## 1.6.199 (April 07, 2024)

- chore: polish blog-list embed

## 1.6.198 (April 07, 2024)

- chore: improve post og image

## 1.6.197 (April 02, 2024)

- fix(editor): incorrect position of typeahead menu on mobile

## 1.6.196 (April 01, 2024)

- fix(label): resolve permission bug due to empty session
- chore: update deps

## 1.6.195 (March 30, 2024)

- feat: improve discussion searching & mobile ux

## 1.6.194 (March 29, 2024)

- chore: polish post-card on docs page

## 1.6.193 (March 29, 2024)

- fix: wrong posts query logic

## 1.6.192 (March 29, 2024)

- fix: bug fixes

## 1.6.191 (March 29, 2024)

- fix: ci bundle bug

## 1.6.190 (March 29, 2024)

- chore: ui/ux improvements

## 1.6.189 (March 29, 2024)

- chore: ui/ux improvements

## 1.6.188 (March 28, 2024)

- chore: add '/api/call/posts/:id/comments' api

## 1.6.187 (March 26, 2024)

- chore: polish chat suggestions

## 1.6.186 (March 26, 2024)

- chore: polish chat module UI / UX

## 1.6.185 (March 26, 2024)

- chore: add textContent param to '/call/posts/:id' to get plain text

## 1.6.184 (March 25, 2024)

- chore: add '/call/posts' endpoint for post searching

## 1.6.183 (March 25, 2024)

- feat: support passport-based access control on labels

## 1.6.182 (March 25, 2024)

- chore(api): add '/sql' endpoint

## 1.6.181 (March 22, 2024)

- fix(discussion-list): filter out certain board types

## 1.6.180 (March 22, 2024)

- chore: polish bookmark module UI / UX

## 1.6.179 (March 22, 2024)

- chore: ui improvements to blog list and editor

## 1.6.178 (March 21, 2024)

- chore: update deps

## 1.6.177 (March 21, 2024)

- chore: update deps

## 1.6.176 (March 21, 2024)

- fix: correct spacing issue between input labels

## 1.6.175 (March 20, 2024)

- chore: chat UI / UX change
- chore: polish bookmark UI / UX (#2251)
- chore: ui/ux improvements (#2250)

## 1.6.174 (March 20, 2024)

- feat(editor): add support for embedding external post links

## 1.6.173 (March 18, 2024)

- chore: update deps

## 1.6.172 (March 18, 2024)

- fix: profile page bugs

## 1.6.171 (March 16, 2024)

- fix: bundle eslint bug

## 1.6.170 (March 16, 2024)

- chore: polish all modules permission

## 1.6.169 (March 15, 2024)

- chore(discussion): ui improvements

## 1.6.168 (March 14, 2024)

- feat(editor): support translation by browser

## 1.6.167 (March 11, 2024)

- chore(editor): improve table columns display

## 1.6.166 (March 11, 2024)

- refactor: improve label-input component(#2160)

## 1.6.165 (March 11, 2024)

- fix: migration file

## 1.6.164 (March 10, 2024)

- fix: boards modification from comments and demo

## 1.6.163 (March 08, 2024)

- chore: update deps

## 1.6.162 (March 07, 2024)

fix: fix and modify bookmark/blog/boards manager with boards

## 1.6.161 (March 07, 2024)

- fix: move react-flip-toolkit from devDeps to deps

## 1.6.160 (March 06, 2024)

- chore: polish bookmark board logic

## 1.6.159 (March 06, 2024)

- feat: add board i18n support(#197)

## 1.6.158 (March 06, 2024)

- fix: add try catch error in crawler

## 1.6.157 (March 05, 2024)

- fix: ci issues

## 1.6.156 (March 05, 2024)

- fix: import issue

## 1.6.155 (March 05, 2024)

- feat: add board to bookmark and blog and others modify

## 1.6.154 (March 05, 2024)

- chore(chat): move most active chat session to top(#2176)
- fix(editor): fix post embed issue caused by the "/" mountpoint
- fix: #2187

## 1.6.153 (March 05, 2024)

- chore: improvements to post assignment(#2201, #2190)

## 1.6.152 (March 04, 2024)

- fix: resolve the bug of blocklet mountPoint is '/' or ''

## 1.6.151 (March 01, 2024)

- chore: update prefs to disable assignment feature by default

## 1.6.150 (March 01, 2024)

- ci: fix build error

## 1.6.149 (March 01, 2024)

- feat: add post/label-based task management support
- fix: #2173
- fix: #1387

## 1.6.148 (February 29, 2024)

- chore: re-bump version

## 1.6.147 (February 29, 2024)

- feat: support for incremental crawling of pages using crawler

## 1.6.146 (February 27, 2024)

- feat: bundle compact size

## 1.6.145 (February 25, 2024)

- fix: resolve the bug of revoke passport still show badge

## 1.6.144 (February 23, 2024)

- fix: profile page bugs

## 1.6.143 (February 23, 2024)

- chore: labels improvements

## 1.6.142 (February 23, 2024)

- fix: profile page bugs and notification

## 1.6.141 (February 23, 2024)

- chore: optimization of the bookmark module
- fix: #1765
- fix: #1745
- fix: #1787
- fix: #1947
- fix: #1986

## 1.6.140 (February 21, 2024)

- fix: profile page bugs and update

## 1.6.139 (February 21, 2024)

- fix: fix layout issue on discussion page

## 1.6.138 (February 21, 2024)

- fix(seo): correct incorrect blog urls in sitemap

## 1.6.137 (February 21, 2024)

- chore: improve layout of discussion add/edit page(#2100, #2116)

## 1.6.136 (February 20, 2024)

- fix: profile page css

## 1.6.135 (February 20, 2024)

- chore: update cached user info when user profile switched(#1842)
- refactor(blog): remove unnecessary image resizing logic

## 1.6.134 (February 20, 2024)

- feat: new tab for profile page and bugs fix

## 1.6.133 (February 20, 2024)

- fix: some improvements related to post locales
- fix: disable occ check for blog post update(#1772)
- fix: #2087, #1021

## 1.6.132 (February 20, 2024)

- chore: remove prettier format html logic

## 1.6.131 (February 20, 2024)

- fix: polish crawler format html bug

## 1.6.130 (February 20, 2024)

- chore: polish crawler logic

## 1.6.129 (February 19, 2024)

- feat: follows tab for profile page

## 1.6.128 (February 18, 2024)

- fix: profile page bugs

## 1.6.127 (February 18, 2024)

- chore: update pages deps

## 1.6.126 (February 18, 2024)

- chore(blog): responsiveness improvements
- chore: improve responsive style for editor toolbar(#2035)
- fix: #2066
- fix: #2033
- chore: update deps

## 1.6.125 (February 17, 2024)

- fix: ui-react version issues

## 1.6.124 (February 17, 2024)

- fix: profile page bugs

## 1.6.123 (February 07, 2024)

- ci: fix build error

## 1.6.122 (February 07, 2024)

- fix: improve translation stability and performance
- feat(translation): support special nodes such as link node, nested list items(#1056,#1849)

## 1.6.121 (February 07, 2024)

- feat: polish crawler logic to support mixed seo html

## 1.6.120 (February 07, 2024)

- chore: update deps

## 1.6.119 (February 06, 2024)

- fix: fix emoji reaction color display(#1994)
- fix: display original image in editor to avoid blur(#2056)
- fix: #2055

## 1.6.118 (February 06, 2024)

- fix: user profile some bugs

## 1.6.117 (February 05, 2024)

- fix(discussion): show 404 page for non-existing posts(#1791)

## 1.6.116 (February 05, 2024)

- chore(editor): upgrade lexical editor to 0.13.1
- fix(editor): fix table column resizing issue due to z-index
- fix(editor): update table plugin & styles
- chore(editor): update DraggableBlockPlugin
- chore(editor): remove font button from editor toolbar

## 1.6.115 (February 03, 2024)

-feat: user center

## 1.6.114 (February 02, 2024)

- chore: adjust og image for docs

## 1.6.113 (February 02, 2024)

- chore: move blog post settings to drawer
- fix(doc): correct incorrect og tags(#1840)

## 1.6.112 (February 01, 2024)

- chore: add sitemap capability to blocklet.yml

## 1.6.111 (February 01, 2024)

- fix: remove components store

## 1.6.110 (February 01, 2024)

- fix: fix navigation issue when accessing doc search results(#1953)
- chore: increase timeout for meilisearch client

## 1.6.109 (February 01, 2024)

- fix: upgrade pages api

## 1.6.108 (February 01, 2024)

- fix: fix crash when update labels of a blog post on discussion page

## 1.6.107 (January 31, 2024)

- chore: add pageskit-based banner to doc/blog page

## 1.6.106 (January 31, 2024)

- feat: new discuss-kit supported installer

## 1.6.105 (January 31, 2024)

- fix: upgrade pages api

## 1.6.104 (January 31, 2024)

- chore: polish post-card component

## 1.6.103 (January 31, 2024)

- chore: improve post card and docs page

## 1.6.102 (January 30, 2024)

- fix: upgrade pages-kit api

## 1.6.101 (January 30, 2024)

- chore: update `/batch-update-slug/:board` api
- chore: display system labels by default
- fix: #1987

## 1.6.100 (January 29, 2024)

- chore: polish CardList component

## 1.6.99 (January 29, 2024)

- chore: fix build error

## 1.6.98 (January 29, 2024)

- chore: improve post list and collection page
- fix: #1960

## 1.6.97 (January 29, 2024)

- chore: update deps

## 1.6.96 (January 28, 2024)

- fix: fix broken links in SubpageListing

## 1.6.95 (January 28, 2024)

- chore: revamp doc-boards page

## 1.6.94 (January 27, 2024)

- fix: resolve the bug of bookmark label filter logic

## 1.6.93 (January 27, 2024)

- feat: add bookmark label filter

## 1.6.92 (January 27, 2024)

- fix: bookmark auto login redirect bug

## 1.6.91 (January 26, 2024)

- chore: improvements to post translation
- fix: #1021
- fix: #1827
- chore: logging refactoring

## 1.6.90 (January 26, 2024)

- chore: improve bookmark logic

## 1.6.89 (January 26, 2024)

- feat(doc): support subpage listing
- feat: add support for post icons

## 1.6.88 (January 26, 2024)

- fix: fix slugify bug with emoji

## 1.6.87 (January 25, 2024)

- chore: improve subscription public content

## 1.6.86 (January 24, 2024)

- chore: doc slug normalization

## 1.6.85 (January 24, 2024)

- feat: allow modifying label slug & refactor label creation/update logic(#1935)
- fix: #1937

## 1.6.84 (January 23, 2024)

- fix: resolve the bug of bundle error

## 1.6.83 (January 23, 2024)

- chore: refactor subscription logic

## 1.6.82 (January 23, 2024)

- chore: improvements to PostLinkEmbedPlugin and doc pages routing
- fix: #1940

## 1.6.81 (January 23, 2024)

- fix: some ai kit bugs

## 1.6.80 (January 22, 2024)

- feat: add slug support for docs
- fix: #1891

## 1.6.79 (January 22, 2024)

- fix: polish bookmark view access to public

## 1.6.78 (January 19, 2024)

- fix: fix doc page navigation problem(#1916)

## 1.6.77 (January 19, 2024)

- fix: polish initDataFromResources from pre-start.js to resources.js

## 1.6.76 (January 19, 2024)

- fix: upgrade pages-kit api

## 1.6.75 (January 19, 2024)

- feat: support for blocklet pack export resources and import resources

## 1.6.74 (January 18, 2024)

- chore: improve tags page

## 1.6.73 (January 18, 2024)

- fix: improve collection posts search

## 1.6.72 (January 18, 2024)

- chore: update pages-kit to latest

## 1.6.71 (January 18, 2024)

- chore: improve collection page
- chore: hide collection header if custom component exists(#1908)

## 1.6.70 (January 17, 2024)

- chore: update pages-kit to latest

## 1.6.69 (January 16, 2024)

- fix: improve labels picker component(#1899, #1900)

## 1.6.68 (January 16, 2024)

- feat: integrate pages-kit custom component into collection page

## 1.6.67 (January 16, 2024)

- fix: doc links issue with pageGroup
- fix: #1890

## 1.6.66 (January 15, 2024)

- fix: some ai-kit bugs

## 1.6.65 (January 13, 2024)

- chore: better url handling in ClickableLinkPlugin

## 1.6.64 (January 12, 2024)

fix: comment scroll problem with pics

## 1.6.63 (January 12, 2024)

- fix: some ai-kit related bugs

## 1.6.62 (January 12, 2024)

- refactor: dark theme and style refactorings

## 1.6.61 (January 11, 2024)

- feat: improve pdf plugin and add `@blocklet/pdf` lib

## 1.6.60 (January 11, 2024)

- fix: deny guest access to management pages(#1872)
- chore: improve styles for editor checklist(#1863)

## 1.6.59 (January 09, 2024)

- chore: update deps

## 1.6.58 (January 09, 2024)

- fix(doc): make toc position fixed

## 1.6.57 (January 09, 2024)

- fix: add ask permission

## 1.6.56 (January 09, 2024)

- chore: improve editor styles
- chore: display toc on doc page(#376)
- fix: #1839

## 1.6.55 (January 09, 2024)

- feat: add web notification

## 1.6.54 (January 08, 2024)

- chore: ui improvements (#1841, #1776)

## 1.6.53 (January 08, 2024)

- fix(editor): remove redundant anchors within headings(#1737)
- fix: #1845

## 1.6.52 (January 05, 2024)

- feat: support for new plugin: Custom Change Plugin, Template Plugin, PDF Plugin

## 1.6.51 (January 05, 2024)

- chore: typography & editor theme improvements

## 1.6.50 (January 05, 2024)

- update: remove chip and change icon color

## 1.6.49 (January 05, 2024)

- fix: add save function to window
- feat: make the pinned posts more prominent
- fix: fix mention menu position
- fix: fix menu item display issues
- fix: draft not count and display views

## 1.6.48 (January 03, 2024)

- update: ui dependency update

## 1.6.47 (January 03, 2024)

- chore: downgrade react-router-dom to 6.10.0

## 1.6.46 (January 02, 2024)

- fix: polish puppeteer config logic

## 1.6.45 (January 02, 2024)

- chore: update react-router-dom to latest

## 1.6.44 (December 30, 2023)

- fix: remove trailing hash from title of toc(#1761)

## 1.6.43 (December 29, 2023)

- fix: update max length of board title to 100(#1807)

## 1.6.42 (December 29, 2023)

- update: adjusting delete button to settings drawer

## 1.6.41 (December 29, 2023)

- chore(doc): hide the default board without any posts
- chore: improve avatar/image clarity

## 1.6.40 (December 29, 2023)

- ci: update node version to 18 in actions

## 1.6.39 (December 29, 2023)

- chore: move uncategorized docs to the added `docs` board
- chore: add updateImmediately prop to GithubLabelPicker component
- fix: make board cards equal height

## 1.6.38 (December 28, 2023)

- fix: fix scroll issue on doc page

## 1.6.37 (December 28, 2023)

- fix: fix api endpoint for updating post labels

## 1.6.36 (December 27, 2023)

- feat: support for resizable document sliders

## 1.6.35 (December 27, 2023)

- fix: resolve the bug of bookmarkItem decode string bug

## 1.6.34 (December 26, 2023)

- fix: layout problem on docs home page
- fix: fix cover image url on bookmark card

## 1.6.33 (December 26, 2023)

- chore: doc-related improvements (#1773)
- chore: polish getAbsoluteUrl logic
- fix: fix incorrect og tags on tag-collection page

## 1.6.32 (December 26, 2023)

- chore: improve collections page(#1767)
- chore(bookmark): add disableEnforceFocus to add dialog

## 1.6.31 (December 26, 2023)

- feat: support show pick tip in add bookmark dialog
- fix: keep doc board consistent with ancestors(#1751) (#1763)
- fix: polish formatDate logic

## 1.6.30 (December 25, 2023)

- fix: chat with correct web title

## 1.6.29 (December 24, 2023)

- fix: resolve the bug of embed docs bug

## 1.6.28 (December 24, 2023)

- fix: resolve the bug of docs can not be modified
- fix: resolve the bug of dayjs format error

## 1.6.27 (December 24, 2023)

- fix: resolve the bug of docs seo site map

## 1.6.26 (December 24, 2023)

- chore: polish board param logic

## 1.6.25 (December 23, 2023)

- fix: resolve the bug of Link missing board=xxx search param

## 1.6.24 (December 22, 2023)

- chore: fix sql script splitting issue

## 1.6.23 (December 22, 2023)

- fix(doc): bug fixes

## 1.6.21 (December 22, 2023)

- feat: doc-related improvements

## 1.6.20 (December 21, 2023)

- fix: resolve the bug of bookmark.js show empty content

## 1.6.19 (December 21, 2023)

- chore(editor): improve heading style

## 1.6.18 (December 21, 2023)

- chore: improve styles for CorpPosts component

## 1.6.17 (December 21, 2023)

- chore: improve bookmark logic

## 1.6.16 (December 21, 2023)

- fix: improve HeadingsIdPlugin to avoid crash in safari

## 1.6.15 (December 20, 2023)

- chore(editor): improve HeadingsIdPlugin
- fix: #1621

## 1.6.14 (December 20, 2023)

- chore: improve display of bookmarked videos on tags/collections page

## 1.6.13 (December 19, 2023)

- feat: support for adding video bookmark

## 1.6.12 (December 19, 2023)

- chore: polish tag collection page(#1714)

## 1.6.11 (December 19, 2023)

- feat: add support for tagging bookmark posts
- fix: #1709, #1714

## 1.6.10 (December 18, 2023)

- chore: improve bookmarklet tip

## 1.6.9 (December 18, 2023)

- fix: fix infinite redirect issue on dashboard pages

## 1.6.8 (December 18, 2023)

- fix: resolve the bug of bookmark.js not working

## 1.6.7 (December 15, 2023)

- fix: polish search bookmark error logic

## 1.6.6 (December 15, 2023)

- fix: polish bookmark error logic

## 1.6.5 (December 15, 2023)

- chore: polish tags page(#1693)

## 1.6.4 (December 15, 2023)

- fix: bug fixes related to tag-collections (#1692, #1690, #1689, #1688, #1687, #1686)

## 1.6.3 (December 15, 2023)

- chore: improve the bookmark

## 1.6.2 (December 15, 2023)

- fix: correct parameters type

## 1.6.1 (December 15, 2023)

- chore: polish collections page

## 1.6.0 (December 15, 2023)

- feat: tagging-related improvements

## 1.5.214 (December 14, 2023)

- fix(editor): fix incorrect video path

## 1.5.213 (December 14, 2023)

- fix: upgrade assistant api

## 1.5.212 (December 13, 2023)

- feat: add open graph support to tag-collection page

## 1.5.211 (December 08, 2023)

- chore: tweak collection-info styles
- chore: update blog title maxLength to 140
- fix: #1633

## 1.5.210 (December 08, 2023)

- feat: support for new bookmark type

## 1.5.209 (December 07, 2023)

- fix: private-route should wait session.initialized

## 1.5.208 (December 07, 2023)

- fix: login should go to blocklet-service login page

## 1.5.207 (December 07, 2023)

- fix: fix broken links to tag collection page

## 1.5.206 (December 07, 2023)

- chore: improve tag-collection page

## 1.5.205 (December 07, 2023)

- chore: improve tag-collection page

## 1.5.204 (December 07, 2023)

- fix: refactor getuser function to fix undefined username(#1614)

## 1.5.203 (December 07, 2023)

- chore: style tweaks for CorpPosts component

## 1.5.202 (December 07, 2023)

- feat: add tag-collection support & labels-related refactorings

## 1.5.201 (December 05, 2023)

- refactor(blocklet-embed): use EmbedIframe

## 1.5.200 (December 05, 2023)

- chore: update deps

## 1.5.199 (December 04, 2023)

- chore: polish blog detail page

## 1.5.198 (December 04, 2023)

- feat: support for picking remote url as a discussion

## 1.5.197 (December 04, 2023)

- fix: incorrect publish date on recommended posts

## 1.5.196 (December 03, 2023)

- chore: add a new rest api to update posts excerpt(#1590)

## 1.5.195 (December 03, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.194 (December 01, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.193 (December 01, 2023)

- chore: improve translation ux

## 1.5.192 (November 30, 2023)

- fix: fix bug in getMentionsFromContent

## 1.5.191 (November 29, 2023)

- chore: blog ui improvements

## 1.5.190 (November 28, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.189 (November 28, 2023)

- fix(editor): fix link behavior in editable mode
- chore: improve responsive style for youtube video(#1569)

## 1.5.188 (November 28, 2023)

- feat(editor): add video support
- chore: fix bug in blockletExists function
- chore: remove uppload

## 1.5.187 (November 25, 2023)

- fix: #1570
- fix: #1569

## 1.5.186 (November 24, 2023)

- fix: resolve the bug of badge wrap not working in chat

## 1.5.185 (November 24, 2023)

- fix: resolve the bug of reply comment not trigger point up
- fix: polish badge icon logic
- chore: update uploader deps

## 1.5.184 (November 24, 2023)

- feat(blog): add corp template & improve blog ui

## 1.5.183 (November 20, 2023)

- refactor: migrate wsClient to ux libs

## 1.5.182 (November 20, 2023)

- fix: resolve the bug of lazy load lottie

## 1.5.181 (November 20, 2023)

- chore: doc nav-menu improvements
- fix: #1501

## 1.5.180 (November 20, 2023)

- chore: bump-version

## 1.5.179 (November 17, 2023)

- feat: support for joint point up blocklet

## 1.5.178 (November 17, 2023)

- feat: serve assets in resource blocklets

## 1.5.177 (November 17, 2023)

- chore: improve editor checkbox plugin(#1372)
- tweak logging(#1545)
- fix: #1548
- fix: #1547

## 1.5.176 (November 16, 2023)

- chore: update deps

## 1.5.175 (November 15, 2023)

- chore: update dall e 3
- [skip ci] Update README.md

## 1.5.174 (November 15, 2023)

- fix: enable CheckboxPlugin on doc page(#1516)

## 1.5.173 (November 15, 2023)

- fix: og tags rendering problem with pageGroup
- chore: improve cache logic for template rendering

## 1.5.172 (November 14, 2023)

- fix: resolve the bug of crawler ua not defined

## 1.5.171 (November 10, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.170 (November 08, 2023)

- fix: #1503
- fix: #1508
- fix: #1464
- fix default value for post#publishTime

## 1.5.169 (November 07, 2023)

- feat: add social share buttons for posts

## 1.5.168 (November 06, 2023)

- chore: normalize og meta tags

## 1.5.167 (November 06, 2023)

- bump-version

## 1.5.166 (November 06, 2023)

- chore: update deps, for better login & logout experience

## 1.5.165 (November 06, 2023)

- chore: disable sequelize logging by default

## 1.5.164 (November 03, 2023)

- chore: update deps

## 1.5.163 (November 02, 2023)

- chore: improve translation UX(#1464)
- fix: #1472
- fix: #1476

## 1.5.162 (November 02, 2023)

- chore: improve paywall component

## 1.5.161 (October 31, 2023)

- feat: allow creating new posts by using existing posts(#1206)

## 1.5.160 (October 31, 2023)

- fix: normalize blog slug to avoid 404 error on blog page

## 1.5.159 (October 30, 2023)

- feat: support slack notification when a discussion is created

## 1.5.158 (October 30, 2023)

- fix: adjust helmet to render og tags properly

## 1.5.157 (October 30, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.156 (October 28, 2023)

- chore: update deps

## 1.5.155 (October 27, 2023)

- chore: optimize size of og image

## 1.5.154 (October 27, 2023)

- fix: fix broken dm chat entrance
- chore: better blog og:image

## 1.5.153 (October 26, 2023)

- chore: update puppeteer and adjust 304 status code logic

## 1.5.152 (October 26, 2023)

- fix: resolve the bug of @blocklet/crawler

## 1.5.151 (October 26, 2023)

- feat: add basic support for content subscription

## 1.5.150 (October 26, 2023)

- chore: polish the logic of @blocklet/crawler

## 1.5.149 (October 25, 2023)

- fix: catch meilisearch errors to avoid crash
- fix(editor): fix svg image display issue
- fix: #1423
- fix: avoid opening extra windows when click on a github embed

## 1.5.148 (October 24, 2023)

- chore: improve translation-input components

## 1.5.147 (October 24, 2023)

- chore: polish @blocklet/crawler SEO logic

## 1.5.146 (October 23, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.145 (October 23, 2023)

- fix: resolve the bug of badge trim not matching

## 1.5.144 (October 23, 2023)

- chore: improve labels styles
- fix: #1434

## 1.5.143 (October 21, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.142 (October 20, 2023)

- fix: board update should work properly(#1427)

## 1.5.141 (October 18, 2023)

- fix: some bug fixes(#1356, #1341, #1402, #1407)

## 1.5.140 (October 18, 2023)

- fix: permission issue related to updating docs

## 1.5.139 (October 17, 2023)

- fix: make ai translation more reliable(#1398)

## 1.5.138 (October 17, 2023)

- fix: resolve the bug of blocklet bundle missing module.exports

## 1.5.137 (October 17, 2023)

- chore: improve displaying of labels(#475)

## 1.5.136 (October 17, 2023)

- fix: 403 error code

## 1.5.135 (October 16, 2023)

- fix: resolve the bug of missing .puppeteerrc.js

## 1.5.134 (October 16, 2023)

- chore: adjust SEO Crawler logic

## 1.5.133 (October 16, 2023)

- chore: upgrade to vite 4

## 1.5.132 (October 15, 2023)

- fix: fix sorting issue with doc navmenu(#1403)

## 1.5.131 (October 15, 2023)

- fix: restore yarn.lock to fix page crash

## 1.5.130 (October 14, 2023)

- chore: polish puppeteer launch logic

## 1.5.129 (October 13, 2023)

- fix: ensure sqlite is installed before starting

## 1.5.128 (October 13, 2023)

- fix(editor): embed-related improvements

## 1.5.127 (October 13, 2023)

- feat: support SEO crawler

## 1.5.126 (October 12, 2023)

- feat(doc): support Ctrl+S shortcut for saving changes
- feat(editor): add SafeAreaPlugin (#1033)
- chore: enhance useAutoSaveState hook

## 1.5.125 (October 11, 2023)

- fix: pagination issue in blog/comment list

## 1.5.124 (October 10, 2023)

- fix(embed): improve twitter url matching

## 1.5.123 (October 10, 2023)

- fix: fix conflict error when updating replies in safari(#1392)

## 1.5.122 (October 08, 2023)

- feat: display posts/comments in realtime(#1372)

## 1.5.121 (October 06, 2023)

- chore: migrate from prisma to sequelize

## 1.5.120 (September 28, 2023)

- fix: resolve the bug of custom passport can not set badge

## 1.5.119 (September 28, 2023)

- chore: adjust badges style
- chore: remove useless code

## 1.5.118 (September 28, 2023)

- chore: adjust badges ux and logic

## 1.5.117 (September 28, 2023)

- feat: support for user badge customization via blocklet prefs

## 1.5.116 (September 27, 2023)

- fix: polyfill Object.hasOwn (#1355)

## 1.5.115 (September 27, 2023)

- chore(ux): update uploader lib

## 1.5.114 (September 26, 2023)

- chore: update blocklet.yml

## 1.5.113 (September 25, 2023)

- fix: make nested comments anchorable(#1357)

## 1.5.112 (September 20, 2023)

- fix: improve displaying & loading of cover images(#1141)

## 1.5.111 (September 20, 2023)

- chore: optimize og image

## 1.5.110 (September 20, 2023)

- chore: add locale parameter to fetchBlogs(#1334)

## 1.5.109 (September 19, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.108 (September 19, 2023)

- chore: improvements related to blog tags

## 1.5.107 (September 19, 2023)

- chore: improve responsiveness of excalidraw preview

## 1.5.106 (September 19, 2023)

- chore: improve latest blog list embed
- fix: fix broken links on tags page

## 1.5.105 (September 19, 2023)

- chore: use named imports for icons-material

## 1.5.104 (September 18, 2023)

- fix: fix layout issue with drawer on docs page

## 1.5.103 (September 18, 2023)

- chore: update @blocklet/uploader

## 1.5.102 (September 18, 2023)

- chore: add Image Bin component to blocklet.yml

## 1.5.101 (September 18, 2023)

- feat: use @blocklet/uploader to replace uppload

## 1.5.100 (September 17, 2023)

- feat: add blog tags page

## 1.5.99 (September 16, 2023)

- fix(deps): lock @mui/x-date-pickers to 5.0.20

## 1.5.98 (September 16, 2023)

- chore: bump deps to latest

## 1.5.97 (September 15, 2023)

- chore: improvements & refactorings for post translations

## 1.5.96 (September 15, 2023)

- fix: comment list crash

## 1.5.95 (September 14, 2023)

- chore: adaptation theme color

## 1.5.94 (September 12, 2023)

- chore: update translate table if exit

## 1.5.93 (September 12, 2023)

- chore: update session manager nav items

## 1.5.92 (September 12, 2023)

- chore: update deps

## 1.5.91 (September 09, 2023)

- fix: #1279

## 1.5.90 (September 08, 2023)

- chore: add call image upload

## 1.5.89 (September 08, 2023)

- fix(page-group): incorrect path for doc edit page

## 1.5.88 (September 08, 2023)

- chore: add the update api for call component

## 1.5.87 (September 07, 2023)

- fix: blog update error from cron task

## 1.5.86 (September 06, 2023)

- chore: add white_check_mark reaction option
- fix: #1081

## 1.5.85 (September 06, 2023)

- chore(editor): upgrade lexical editor to 0.12.x
- feat(editor): add AlertPlugin support
- chore(editor): optimize image loading in editor
- fix(editor): fix issue with toggling collapsible component
- chore(editor): update CollapsiblePlugin & TablePlugin

## 1.5.84 (September 06, 2023)

- fix: fix display issue with reactions on comments(#1256)
- chore(doc): use localStorage to persist asideOpen state

## 1.5.83 (September 06, 2023)

- chore: update deps
- [skip ci] Update README.md

## 1.5.82 (September 05, 2023)

- fix: schedule time style in dark theme

## 1.5.81 (September 04, 2023)

- chore:expand the title text character limit

## 1.5.80 (September 04, 2023)

- fix: h1 font color in dark theme

## 1.5.79 (September 01, 2023)

- chore: increase default display size for excalidraw drawings

## 1.5.78 (September 01, 2023)

- feat: add comments support to blog posts

## 1.5.77 (September 01, 2023)

- fix: fix scroll problem on doc page

## 1.5.76 (September 01, 2023)

- feat: add comments support to blog posts
- fix: avoid updating outdated comment data

## 1.5.75 (August 31, 2023)

- fix: properly display page title
- chore: limit max length of post titles to 60 chars

## 1.5.74 (August 31, 2023)

- feat: allow uploading image in feedback mode
- chore: improve i18n support on add-discussion page

## 1.5.73 (August 29, 2023)

- chore: requests permission verification on the interface

## 1.5.72 (August 29, 2023)

- fix: scroll to top on every route change(#1230)
- fix #1201
- fix #976

## 1.5.71 (August 28, 2023)

- chore: add publication time when you send an article

## 1.5.69 (August 25, 2023)

- chore: polish add-discussion page

## 1.5.68 (August 24, 2023)

- chore: polish styles

## 1.5.67 (August 24, 2023)

- chore: update deps

## 1.5.66 (August 24, 2023)

- chore: support using new-discussion page to submit feedback

## 1.5.65 (August 23, 2023)

- feat: add support for emoji-based reactions
- fix #1220

## 1.5.64 (August 23, 2023)

- fix: give prompt when discarding unsaved drawing

## 1.5.63 (August 18, 2023)

- ci: fix build error

## 1.5.62 (August 18, 2023)

- fix: fix broken login page

## 1.5.61 (August 18, 2023)

- chore: doc edit & multilingual improvements

## 1.5.60 (August 17, 2023)

- chore: update package

## 1.5.59 (August 17, 2023)

- chore: remove cache blocklet js

## 1.5.58 (August 16, 2023)

- chore: update deps

## 1.5.57 (August 16, 2023)

- chore: replace react use package

## 1.5.56 (August 16, 2023)

- Revert "chore: replace react use (#1190)"

## 1.5.55 (August 16, 2023)

- chore: replace react use (#1190)

## 1.5.54 (August 16, 2023)

- fix: react-use the usage

## 1.5.53 (August 16, 2023)

- chore: ignore chat url theme

## 1.5.52 (August 16, 2023)

- feat: ensure smaller logo and favicon size

## 1.5.51 (August 15, 2023)

- refactor: remove useCommentSettings hook

## 1.5.50 (August 15, 2023)

- chore: add color for embed card list

## 1.5.49 (August 15, 2023)

- chore: polish blog cards(#1174)

## 1.5.48 (August 15, 2023)

- fix: entering illegal colors should not cause discuss kit to crash #1147

## 1.5.47 (August 15, 2023)

- fix: exclude private discussions from sitemap

## 1.5.46 (August 15, 2023)

- chore: set the link open mode

## 1.5.45 (August 15, 2023)

- fix: remove chinese chars from slug

## 1.5.44 (August 14, 2023)

- fix: css styles blink when the CSS is loaded asynchronously

## 1.5.43 (August 14, 2023)

- fix: fix sorting issue with doc catalog

## 1.5.42 (August 14, 2023)

- fix: avoid sending duplicate notifications(#622)
- feat: allow disabling notification badge
- chore: use post title as notification title(#1160)
- fix: properly notify mentioned users when post is updated

## 1.5.41 (August 14, 2023)

- fix: add a whitelist for custom theme
- chore: added the icon configuration item

## 1.5.40 (August 14, 2023)

- fix: prevent new lines in title input field(#1131)

## 1.5.39 (August 14, 2023)

- fix: embed announcement crash in safari

## 1.5.38 (August 12, 2023)

- feat: fallback to server powered open graph

## 1.5.37 (August 12, 2023)

- feat: support customizing doc catalog

## 1.5.36 (August 12, 2023)

- chore: support announcement embed

## 1.5.35 (August 11, 2023)

- feat: support history versions for blog posts

## 1.5.34 (August 11, 2023)

- fix: discuss list page style in custom theme model

## 1.5.33 (August 11, 2023)

- feat: add label filter for latest blog embedding
- fix: fix problem of missing pre-start script in dev environment

## 1.5.32 (August 10, 2023)

- fix: header border in dark model

## 1.5.31 (August 10, 2023)

- chore: support set theme color

## 1.5.30 (August 09, 2023)

- fix: remove comment urls from sitemap

## 1.5.29 (August 09, 2023)

- fix: fix broken urls in sitemap

## 1.5.28 (August 09, 2023)

- fix: sitemap host not correct

## 1.5.27 (August 09, 2023)

- feat: support sitemap

## 1.5.26 (August 08, 2023)

- chore: improve doc access control

## 1.5.25 (August 08, 2023)

- chore: improve doc access control

## 1.5.24 (August 04, 2023)

- fix(editor): remove google font import (#934)

## 1.5.23 (August 04, 2023)

- fix: comments not displayed

## 1.5.22 (August 04, 2023)

- fix: team 里一个帖子下不断有 spinner #1115

## 1.5.21 (August 03, 2023)

- chore: update deps
- fix: try to fix email username undefined

## 1.5.20 (August 03, 2023)

- feat: allow hiding reply button for anonymous users
- chore: prevent error prompts related to chats/unread API

## 1.5.19 (August 03, 2023)

- fix: 内容里就出现一个 spinner #1066
- fix: favicon 不能显示的时候可以不显示，不要显示 broken image #1020
- fix: 更高的屏幕上编辑帖子时 Editor 可以占据更大的高度？ #1070

## 1.5.18 (August 03, 2023)

- fix: add @iconify/iconify in @blocklet/editor dependencies

## 1.5.17 (August 01, 2023)

- chore: resize the image size

## 1.5.16 (July 31, 2023)

- chore: remove functions that are not commonly used

## 1.5.15 (July 31, 2023)

- chore: enable AI templates for admin only

## 1.5.14 (July 28, 2023)

- chore: optimize the blog details page

## 1.5.13 (July 28, 2023)

- chore: bump deps to latest
- chore: use latest image service

## 1.5.12 (July 25, 2023)

- chore: bump deps to latest

## 1.5.11 (July 25, 2023)

- chore: use new blocklet plugin

## 1.5.10 (July 25, 2023)

- chore: bump deps to latest
- feat: append image filter param in blog list api
- fix: only attach user when required
- feat: offload brotli/gzip compression to nginx

## 1.5.9 (July 22, 2023)

- fix: image filter param duplication
- feat: use image service to make page load faster

## 1.5.8 (July 20, 2023)

- feat: use inline blocklet.js

## 1.5.7 (July 19, 2023)

- chore: add typescript support to api
- fix #446

## 1.5.6 (July 19, 2023)

- fix: ignore ime input event

## 1.5.5 (July 18, 2023)

- fix(editor): improve display of github/post link on small screens
- chore(blog): simplify logic for extracting excerpts
- chore(editor): update mention highlight color

## 1.5.4 (July 17, 2023)

- fix(blog): fix navigation issue for invalid locale

## 1.5.3 (July 17, 2023)

- chore: tweak editor responsive font size

## 1.5.2 (July 17, 2023)

- chore: update deps

## 1.5.1 (July 15, 2023)

- chore: fix build error

## 1.5.0 (July 15, 2023)

- feat: blog edit improvements
- feat: blog multilingual & translation improvements
- feat: add dirty-prompt component & hooks
- feat: add useAutoSaveState hooks
- chore: add LazyEditor & OnContentChangePlugin & LexicalEditorRefPlugin
- chore: use createBrowserRouter instead of BrowserRouter

## 1.4.25 (July 12, 2023)

- chore: remove unnecessary fields from blog list api

## 1.4.24 (June 30, 2023)

- build(ux): automatically exclude deps from bundle

## 1.4.23 (June 29, 2023)

- fix: SSE should work when browser is hidden(#1037)

## 1.4.22 (June 29, 2023)

- feat(embed): add locale support for latest posts
- fix: fix display issue with chat messages

## 1.4.21 (June 29, 2023)

- fix: improve discussions search

## 1.4.20 (June 28, 2023)

- chore: improve ws reconnect strategy

## 1.4.19 (June 27, 2023)

- feat: support fullscreen mode for excalidraw

## 1.4.18 (June 27, 2023)

- chore: wrap editor with Suspense to avoid re-render issue

## 1.4.17 (June 26, 2023)

- feat: translate editor content while preserving formatting

## 1.4.16 (June 26, 2023)

- feat: support tracking pv with blocklet tracker

## 1.4.15 (June 21, 2023)

- fix: fix crashing issue when searching for discussions

## 1.4.14 (June 20, 2023)

- chore: add pageGroups configs to blocklet.yml

## 1.4.13 (June 20, 2023)

- feat: support localized labels

## 1.4.12 (June 20, 2023)

- chore: update deps

## 1.4.11 (June 18, 2023)

- chore: add editorconfig
- chore: bump deps to latest
- feat: support dynamic routes based on blocklet routeGroup

## 1.4.10 (June 15, 2023)

- fix: bump blocklet sdk to hotfix version

## 1.4.9 (June 13, 2023)

- fix: bump deps to latest to fix cookie domain overwrite

## 1.4.8 (June 12, 2023)

- refactor: use langs from LocaleContext instead of hard-coded ones

## 1.4.7 (June 12, 2023)

- chore: update deps

## 1.4.6 (June 08, 2023)

- chore: polish blog detail page

## 1.4.5 (June 07, 2023)

- chore: add access control to chat channel creation

## 1.4.4 (June 07, 2023)

- fix: should pass embed limit params to api

## 1.4.3 (June 07, 2023)

- fix: lazy load cover-image with placeholder(#950)

## 1.4.2 (June 07, 2023)

- feat: support customization of blog pages with preferences
- chore: polish blog detail/edit page (#941, #930, #942)

## 1.4.1 (June 06, 2023)

- feat: add lazy loading for CoverImage
- chore: update deps
- feat: add skeleton loading for embed page

## 1.4.0 (June 03, 2023)

- feat(blog): support multilingual blog
- feat(blog): support permalinks
- refactor: re-implement post translations module
- chore: improve open graph meta tags on blog page
- chore: blog routes adjustment
- add post /sql/scripts api
- add an api to update meilisearch indexes

## 1.3.49 (May 29, 2023)

- chore: update deps

## 1.3.48 (May 26, 2023)

- feat: support post link embed

## 1.3.47 (May 24, 2023)

- feat: performance optimization

## 1.3.46 (May 24, 2023)

- chore: update deps

## 1.3.45 (May 23, 2023)

- chore: polish blog cards (embed)
- fix: incorrect og:image link

## 1.3.44 (May 23, 2023)

- chore: improve back navigation

## 1.3.43 (May 22, 2023)

- fix: avoid title flickering during initial render

## 1.3.42 (May 19, 2023)

- fix: ai image upload bug

## 1.3.40 (May 19, 2023)

- fix: incorrect logic for deleting board

## 1.3.39 (May 18, 2023)

- fix: editor crash caused by incorrect editor state (#857)

## 1.3.38 (May 18, 2023)

- chore(blog-cards): support single-row layout
- fix #854

## 1.3.37 (May 18, 2023)

- chore: get favicon more rigorously

## 1.3.36 (May 16, 2023)

- fix #657
- fix #754

## 1.3.35 (May 16, 2023)

- chore: preserve the resized dimensions of excalidraw diagrams

## 1.3.34 (May 16, 2023)

- fix: ai image style

## 1.3.31 (My 11, 2023)

- chore: add "textContent" param to blog detail API to fetch plain content

## 1.3.30 (May 11, 2023)

- feat: add ai image action

## 1.3.29 (May 09, 2023)

- fix: fetch url favicon

## 1.3.28 (May 09, 2023)

- fix: incorrect image path caused by resizing

## 1.3.27 (May 09, 2023)

- feat: add view mode support to excalidraw component
- chore: increase maximum request body size

## 1.3.26 (May 08, 2023)

- fix: fetch url favicon

## 1.3.25 (May 07, 2023)

- fix(editor): missing styles for excalidraw component

## 1.3.24 (May 06, 2023)

- chore: improve api error handling

## 1.3.23 (May 06, 2023)

- chore: update deps
- fix: fix incorrect image path

## 1.3.22 (May 06, 2023)

- fix: the loading of the github issue #776
- fix: bookmark should display a favicon #730

## 1.3.21 (May 05, 2023)

- fix: fix error caused by fetching boards for unauthenticated users

## 1.3.20 (May 05, 2023)

- chore: polish board manager

## 1.3.19 (May 05, 2023)

- fix(editor): improve excalidraw component

## 1.3.18 (May 04, 2023)

- fix: blog list rendering error (#778)

## 1.3.17 (May 04, 2023)

- chore: upgrade lexical to 0.10.0

## 1.3.16 (April 29, 2023)

- fix: error handling for AI availability check

## 1.3.15 (April 28, 2023)

- feat: add doc search functionality
- chore: improve doc tree menu
- fix: prevent deletion of default board (#458)
- feat: add support for boards access control

## 1.3.14 (April 28, 2023)

- chore: adjust mobile style

## 1.3.12 (April 26, 2023)

- chore: update @blocklet/embed
- [skip ci] Update README.md

## 1.3.11 (April 26, 2023)

- feat: support deleting of chat messages

## 1.3.10 (April 26, 2023)

- improve global api error handling
- avoid remounting of app caused by conditional rendering
- fix: use occ to fix the "last-commit wins" problem

## 1.3.9 (April 26, 2023)

- chore(chat): adjust mobile style

## 1.3.8 (April 25, 2023)

- chore: update deps
- feat: add @blocklet/embed
- [skip ci] Update README.md

## 1.3.7 (April 25, 2023)

- feat: embed github url inline

## 1.3.6 (April 24, 2023)

- ci: fix github actions error

## 1.3.5 (April 24, 2023)

- feat(doc-mode): multi language support & some improvements

## 1.3.4 (April 18, 2023)

- fix: error when deleting comments (#712)

## 1.3.3 (April 17, 2023)

- feat: send explore feed when blog published
- refactor: refactoring related to post/image url building

## 1.3.2 (April 17, 2023)

- chore: remove link preview (#697)

## 1.3.1 (April 15, 2023)

- fix: add content type validation for API response

## 1.3.0 (April 14, 2023)

- feat: add support for document mode
- chore: add ts support in blocklets/discuss-kit package & fix eslint errors

## 1.2.17 (April 14, 2023)

- feat: embed the private github bookmark

## 1.2.16 (April 14, 2023)

- chore: update deps

## 1.2.15 (April 11, 2023)

- fix: include cookies when fetch blocklet-embed/open-graph info (#614)

## 1.2.14 (April 11, 2023)

- chore: update blocklet readme/screenshots

## 1.2.13 (April 07, 2023)

- fix: after selecting all, clicking on any place will crash (#656)

## 1.2.12 (April 07, 2023)

- fix: click the checkbox more precisely(#665)

## 1.2.11 (April 07, 2023)

- chore: adjust built-in templates to improve editor AI

## 1.2.10 (April 06, 2023)

- fix: display issue with arrow used for text generation(#637)
- chore: display pinned discussions only on first page
- fix: #666

## 1.2.9 (April 04, 2023)

- feat: improve editor's AI capability by integrating ai-assistant

## 1.2.8 (April 04, 2023)

- fix: statistical input words

## 1.2.7 (April 04, 2023)

- feat: transform the text to the title

## 1.2.6 (April 03, 2023)

- fix: sending editor data has no null issues

## 1.2.5 (April 01, 2023)

- ci: restore github actions configs

## 1.2.3 (April 01, 2023)

- ci: fix github actions error

## 1.2.1 (March 31, 2023)

- chore: update blocklet sdk to 1.16.0

## 1.1.9 (March 30, 2023)

- chore: update meilisearch settings to recreate indexes

## 1.1.8 (March 30, 2023)

- fix: optimized plugin for automatically emptying edit box contents

## 1.1.7 (March 30, 2023)

- fix: using backspace to delete list rows doesn't work very well (#424)

## 1.1.6 (March 29, 2023)

- fix: the CheckBox in reading mode cannot be clicked to checked (#427)

## 1.1.5 (March 29, 2023)

- fix: when typing code, if you type tab, you cannot continue typing (#585)

## 1.1.4 (March 28, 2023)

- fix: more accurate matching of input results (#528)

## 1.1.3 (March 27, 2023)

- feat: optimize select all text commands (#384)

## 1.1.2 (March 27, 2023)

- fix: the page for sending input data blinks

## 1.1.1 (March 25, 2023)

- fix: incorrect response data from completions API

## 1.1.0 (March 24, 2023)

- feat: integrate with AI Kit

## 1.0.99 (March 23, 2023)

- feat: custom text float toolbar (#377)

## 1.0.98 (March 23, 2023)

- fix: chat page press Enter to initiate carriage return to repeat rendering (#520);

## 1.0.97 (March 22, 2023)

- fix: experience problems in the input box in Chat mode - / and @ cannot work with Enter properly (#521)

## 1.0.96 (March 22, 2023)

- fix: menu display overflow in chat mode

## 1.0.95 (March 21, 2023)

- chore: use selfhost useMessage

## 1.0.94 (March 20, 2023)

- chore: update deps to latest

## 1.0.93 (March 16, 2023)

- chore: polish blocklet editor

## 1.0.92 (March 14, 2023)

- chore: polish blocklet editor

## 1.0.91 (March 14, 2023)

- feat: support embedding bilibili videos

## 1.0.90 (March 13, 2023)

- feat: add issue templates

## 1.0.89 (March 13, 2023)

- chore: improve layout of blog editing page

## 1.0.88 (March 13, 2023)

- feat: integrate blocklet-embed with blocklet editor
- refactor: refactoring related to open-graph & blocklet-embed

## 1.0.87 (March 09, 2023)

- chore: support empty data in embed "Blog List"

## 1.0.86 (March 08, 2023)

- fix: move fe deps to dev

## 1.0.85 (March 08, 2023)

- chore: add date-fns dependency to package.json

## 1.0.84 (March 08, 2023)

- chore: update deps

## 1.0.83 (March 08, 2023)

- fix: move fe deps to dev

## 1.0.82 (March 08, 2023)

- fix: startup error caused by prisma

## 1.0.81 (March 08, 2023)

- fix: improve mention and notification functionality

## 1.0.80 (March 05, 2023)

- feat: add more variant in "blog list" embed

## 1.0.79 (March 05, 2023)

- chore: update deps
- chore: use @blocklet/sdk/lib/embed relate libs

## 1.0.78 (March 03, 2023)

- feat: allow access to private blog by using blog access token

## 1.0.77 (March 03, 2023)

- fix(editor): a few bug fixes (#589, #470 ,#299)

## 1.0.76 (March 02, 2023)

- fix(editor): bug fixes & mention plugin improvements
- fix: correct upload api path (#575)
- fix: #565, #457, #530

## 1.0.75 (March 02, 2023)

- fix: editor z-index problem in ux dialog

## 1.0.74 (February 28, 2023)

- chore: update deps to fix broken rolling-session

## 1.0.73 (February 28, 2023)

- chore: enable lazy loading for pages
- chore: update vite to 3.2.5

## 1.0.72 (February 28, 2023)

- chore: improve blog-edit page
- chore: order blog posts by publishTime
- chore: update seed data for blogs
- fix: #582
- fix: add autoFocus prop to Editor/Input components (#574,#582)

## 1.0.71 (February 26, 2023)

- fix: display blog cover image correctly

## 1.0.70 (February 24, 2023)

- chore: update margin of list item (#563)
- chore: improve responsive styles for image in editor(#564)
- update lexical to 0.8.0
  - fix build error & update AutoEmbedPlugin
  - add TabIndentationPlugin to Editor & disable AutoFocusPlugin
- chore: adjust command priority for LexicalPopoverMenu and CmdEnterShortcutPlugin

## 1.0.69 (February 23, 2023)

- fix: add check to determine if there are non-text elements in content
- chore: update editor theme to remove text-transform from h1/h2/h3

## 1.0.68 (February 23, 2023)

- fix: image display issue in editor (#558)

## 1.0.67 (February 21, 2023)

- feat: support blocklet cacheable

## 1.0.66 (February 18, 2023)

- fix: #548
- fix: #554
- fix: #551
- fix: #549
- fix: #545

## 1.0.65 (February 17, 2023)

- feat: support saving/unpublishing blog as drafts
- feat: support publishing blog at a specified time

## 1.0.64 (February 14, 2023)

- feat: display page views count on discussion/blog page

## 1.0.63 (February 11, 2023)

- chore: move labels to standalone package
- chore: seed logic can be configured with cli

## 1.0.62 (February 11, 2023)

- fix: embed api issue with blocklet matching

## 1.0.61 (February 11, 2023)

- fix: wrong unread state when sending message

## 1.0.60 (February 11, 2023)

- fix: embed api error

## 1.0.59 (February 10, 2023)

- feat: support notification channel
- feat: improve handling of read/unread state for chats
- refactor: chat event subscription refactoring
- chore: allow pressing Enter to send message
- chore: improve empty input detection (#493)
- fix: #474

## 1.0.58 (February 04, 2023)

- fix: 500 error when publish comment

## 1.0.57 (February 03, 2023)

- fix: #473, #478

## 1.0.56 (February 03, 2023)

- chore: improve connection status bar
- chore: ui improvements

## 1.0.55 (February 02, 2023)

- feat: support group chat (channel)

## 1.0.54 (January 28, 2023)

- feat: support open graph
- chore: polish discussion detail page (#443)
- fix #448

## 1.0.53 (January 28, 2023)

- chore: improve discussion pagination/searching
  related issues: #351,#411,#378,#229,#263

## 1.0.52 (January 20, 2023)

- feat: add blocklet-open-embed support

## 1.0.51 (January 20, 2023)

- feat: add basic support for chat

## 1.0.50 (January 17, 2023)

- chore: improve back button logic

## 1.0.49 (January 16, 2023)

- fix: iframe setting panel support pages-kit cooperation

## 1.0.48 (January 14, 2023)

- feat: notify users when they are mentioned or receive comment/reply

## 1.0.47 (January 14, 2023)

- feat: add labels system
- fix #404
- chore: page layout adjustment & make editor toolbar sticky

## 1.0.46 (January 13, 2023)

- feat: /iframe/latest support setting page

## 1.0.45 (January 12, 2023)

- fix: the title text on tabs
- fix: editor toolbar adapting to small space
- fix: cannot enter the focus on editor

## 1.0.44 (January 11, 2023)

- feat: allow users with update_post permission to update post
- refactor: use AsyncLocalStorage to share security context

## 1.0.43 (January 09, 2023)

- feat: add search in discuss list

## 1.0.42 (January 06, 2023)

- feat: improve post list & support switching posts view mode

## 1.0.41 (January 06, 2023)

- feat: add basic support for rbac

## 1.0.40 (January 04, 2023)

- fix: issue about the typeahead-menu

## 1.0.39 (January 03, 2023)

- feat: add mention in discuss-kit

## 1.0.38 (January 03, 2023)

- chore: update deps to latest

## 1.0.37 (December 30, 2022)

- fix: display problem of code section in editor
- fix: checklist style in editor

## 1.0.36 (December 28, 2022)

- chore: bump version

## 1.0.35 (December 27, 2022)

- fix: issuse of referencing blog list

## 1.0.34 (December 26, 2022)

- chore: use latest ux

## 1.0.33 (December 26, 2022)

- refactor: migrate the editor's code

## 1.0.32 (December 26, 2022)

- feat: upload to prod store

## 1.0.31 (December 25, 2022)

- chore: update and dedupe deps

## 1.0.30 (December 25, 2022)

- feat: add basic support for importing posts data
- chore: tweak blog card styles

## 1.0.29 (December 24, 2022)

- chore: improve responsive styles for blog list

## 1.0.28 (December 23, 2022)

- chore: update deps to latest

## 1.0.27 (December 23, 2022)

- fix: issuse of duplicate like request
- fix: issuse of request failure of home page

## 1.0.26 (December 22, 2022)

- chore: update @blocklet/editor to latest

## 1.0.25 (December 22, 2022)

- feat: add blog-related functionality

## 1.0.24 (December 21, 2022)

- chore: allow a discuss initiated from a blocklet to be deleted

## 1.0.23 (December 20, 2022)

- fix: update editor and change some style
- fix: drafts allow users to freely switch boards

## 1.0.22 (December 17, 2022)

- chore: tweak post-card style
- fix: post-card title should not repeat

## 1.0.21 (December 17, 2022)

- chore: improve responsive styles for discuss list

## 1.0.20 (December 17, 2022)

- chore: add "allowNewDiscussion" to prefs for better access control
- chore: improve responsive styles

## 1.0.19 (December 16, 2022)

- feat: support aggregating discuss & refactor db schema

## 1.0.18 (December 16, 2022)

- chore: update blog detail style

## 1.0.17 (December 14, 2022)

- chore: update deps
- feat: add blog preview mode & add latest blog iframe component

## 1.0.16 (December 13, 2022)

- fix: incorrect homepage link & routes improvements

## 1.0.15 (December 12, 2022)

- feat: editor cache unsent content

## 1.0.14 (December 12, 2022)

- fix: chinese input issue on discussion page

## 1.0.13 (December 10, 2022)

- refactor: rename export module name from DIDComment to DiscussKit

## 1.0.12 (December 09, 2022)

- fix: uploads should work on discussion detail page

## 1.0.11 (December 09, 2022)

- feat: support uploading image
- feat: display all voters when clicking the total number of votes(#215)
- fix: issue with wrong comment position calculation

## 1.0.10 (December 08, 2022)

- chore: some ui improvements
- fix: wrong calculation of total comments

## 1.0.9 (December 08, 2022)

- fix: auto-clear-plugin should work properly

## 1.0.8 (December 08, 2022)

- fix #234
- chore: integrate with @blocklet/editor
- chore: improve error style for comment-input (#232)
- fix #235
- fix #236

## 1.0.7 (December 06, 2022)

- fix: discussion should be able to be deleted by admin

## 1.0.6 (December 06, 2022)

- feat: support deleting/transfering discussion

## 1.0.5 (December 05, 2022)

- chore: pin lexical verison to 0.6.0

## 1.0.4 (December 05, 2022)

- chore: polish navigation

## 1.0.3 (December 05, 2022)

- build: bundling adjustments

## 1.0.2 (December 05, 2022)

- chore: update gitignore
- chore: update navigation for new schema

## 1.0.1 (December 04, 2022)

ci: fix build error

## 1.0.0 (December 03, 2022)

- chore: rename @did-comment/react to @blocklet/discuss-kit
- chore: rename discuss-kit-components to @blocklet/discuss-kit-ux
- chore: enable prisma query logging in dev
- feat: support flatView and "copy link"
- implement cursor-based pagination to searchComments
- add getCommentPosition api
- refactor: organize components into @blocklet/discuss-kit-ux

## 0.8.6 (November 25, 2022)

- feat: add prefs form for discuss-kit

## 0.8.5 (November 23, 2022)

- ci: use actions/setup-node@v3 with node v16

## 0.8.4 (November 23, 2022)

- feat: support pinned/featured discussions
- chore: mark edited discussions as "edited"

## 0.8.3 (November 21, 2022)

- chore: polish header width (#183)
- chore: polish sorting selector component (#180,#179)
- chore: temporarily disable data seeding in prod (#187)

## 0.8.2 (November 20, 2022)

- chore: add hotkeys to save/cancel editing title (#163)
- chore: improve editor theme styles (#163)

## 0.8.1 (November 18, 2022)

- feat: support editing comment/discussion & sorting discussion list
- feat: support displaying latest commenters in discussion list
- improve getUsers logic to avoid potential errors in dev env

## 0.8.0 (November 18, 2022)

- fix: refresh comment list state when user session changes (#114)
- refactor(did-comment): prop renaming (#143)
- chore: remove session-manager at the top of comment list (#118)
- chore: disable the restore button to normal user
- fix: incorrect argument passed to auth-middleware/listCommentsAndReplies

## 0.7.31 (November 16, 2022)

- chore: update logo & theme primary color

## 0.7.30 (November 16, 2022)

- chore: imporve responsive styles for editor
- chore: improve dev environment configuration

## 0.7.29 (November 15, 2022)

- chore: migrate to vite & upgrade eslint-config

## 0.7.28 (November 12, 2022)

- feat: basic implementation of discuss module

## 0.7.27 (November 11, 2022)

- feat: add a api to allow deleting all comments by user did

## 0.7.26 (November 08, 2022)

- feat: migrate to lexical editor

## 0.7.25 (November 05, 2022)

- chore: add error boundary around comment list
- chore: UI Improvements for comment list

## 0.7.24 (November 03, 2022)

- chore: show playground nav link in dev env only
- chore: improve the logic of adding new comments/replies
- chore: restrict minimum nodejs version to 16
- fix: wrong primary color (#116)
- chore: improve sorting of comments (#69)

## 0.7.23 (November 03, 2022)

- feat: show user's avatar and fullName on comment list

## 0.7.22 (November 02, 2022)

- chore: add migration scripts

## 0.7.21 (November 01, 2022)

- feat: re-implement the rating module

## 0.7.20 (October 31, 2022)

- fix: error caused by undefined Notification

## 0.7.19 (October 31, 2022)

- chore(core): upgrade @nedb/\* to 2.0.5

## 0.7.18 (October 29, 2022)

- refactor: migrate from nedb to sqlite & prisma

## 0.7.17 (October 21, 2022)

- feat: add support for replying to a comment
- refactor: lots of code cleanup and refactoring

## 0.7.16 (十月 20, 2022)

- fix(react): resolve the bug of react not defined

## 0.7.15 (十月 20, 2022)

- fix(react): resolve the bug of did-comments-react not provider default ThemeProvider

## 0.7.14 (October 14, 2022)

- fix: ensure that the object already exists when visit comment list page

## 0.7.13 (October 14, 2022)

- feat: add support for thumb up/down reactions to object/comment

## 0.7.12 (October 11, 2022)

- feat: add markdown support for comments

## 0.7.11 (September 16, 2022)

- chore: use latest blocklet ui dashboard

## 0.7.10 (September 14, 2022)

- feat: support viewing comments of current user

## 0.7.9 (September 08, 2022)

- fix: api prefix of @did-comment/react

## 0.7.8 (September 01, 2022)

- fix: release to both store

## 0.7.7 (九月 01, 2022)

- chore: replace ux dashboard with blocklet-ui dashboard

## 0.7.6 (August 26, 2022)

- feat: support submit comment with command+enter
- fix: ci action branch [skip ci]

## 0.7.5 (August 24, 2022)

- chore: update integration docs

## 0.7.4 (August 23, 2022)

- fix: ui component not adaptive

## 0.7.3 (August 23, 2022)

- chore: remove chainHost from config

## 0.7.2 (August 23, 2022)

- chore: publish blocklet to prod store

## 0.7.1 (August 23, 2022)

- fix: ci publish

## 0.7.0 (August 23, 2022)

- chore: rename did-comment-react => @did-comment/ract
- feat: make @did-comment/react adaptive

## 0.6.0 (August 23, 2022)

- chore: update deps to latest safely

## 0.5.0 (August 11, 2022)

- chore: migrate from styled-components to emotion

## 0.4.0 (August 10, 2022)

- chore: update deps to latest safely

## 0.3.0 (May 13, 2022)

- chore: adapter react 18 and mui v5

## 0.2.1 (May 13, 2022)

- fix #45

## 0.2.0 (五月 12, 2022)

- chore:remove useless code

## 0.1.13 (五月 12, 2022)

- chore: add batch query count interface
- chore: add comment callback hooks

## 0.1.12 (April 29, 2022)

- fix some issues

## 0.1.11 (April 27, 2022)

- fix ws auth fail

## 0.1.10 (April 26, 2022)

- support page load
- support auto refresh list
- update style
- support i18n

## 0.1.9 (April 18, 2022)

## 0.1.8 (April 18, 2022)

## 0.1.7 (April 16, 2022)

## 0.1.6 (April 16, 2022)

- some improvements

## 0.1.5 (April 15, 2022)

## 0.1.4 (April 15, 2022)

## 0.1.3 (April 15, 2022)

## 0.1.2 (April 15, 2022)

- update some details

## 0.1.1 (April 13, 2022)

- test github actions
