# Discuss Kit

Discuss Kit offers highly customizable and combinable components for everything you need to decentralize communication. Create a safe, free space for your group to share, discuss and discover new things with each other.

## How To Install Discuss Kit?

You can find and launch Discuss Kit in the [Blocklet Store](https://store.blocklet.dev/). During the installation process, you can choose to install Discuss Kit into a Blocklet Server or purchase a Blocklet Space for quick startup.

## Features

*   Topic Publishing and Discussion
*   Blog Post Management and Publishing
*   AI-powered Content Editing
*   One-on-One and Group Chat Support
*   Easy-to-Integrate Comment Component

Learn more about [Discuss Kit](https://www.web3kit.rocks/en/discuss-kit)

## Integrate comment system into your Blocklet

#### 1. Install @blocklet/discuss-kit

```shell
yarn add @blocklet/discuss-kit
or
npm install @blocklet/discuss-kit
```

#### 2. Use Comments component

```jsx
import { Comments } from '@blocklet/discuss-kit';

<Comments
  target={{
    id: `<content id>`,
    title: `<content title>`,
    desc: `<content description>`,
    owner: `<content author>`,
  }}
/>;
```

When your Blocklet doesn't offer session management, you can use CommentsWithSession component to take care of user sessions autonomously.

```jsx
import { CommentsWithSession } from '@blocklet/discuss-kit';

<CommentsWithSession
  target={{
    id: `<content id>`,
    title: `<content title>`,
    desc: `<content description>`,
    owner: `<content author>`,
  }}
/>;
```
