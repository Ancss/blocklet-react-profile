## Launch on Blocklet Server

[![Launch on Blocklet Server](https://assets.arcblock.io/icons/launch_on_blocklet_server.svg)](https://install.arcblock.io/launch?action=blocklet-install\&meta_url=https%3A%2F%2Fgithub.com%2Fblocklet%2Fdiscuss-kit%2Freleases%2Fdownload%2Fv2.0.56%2Fblocklet.json)

# Discuss Kit

> TODO: 这里补充如何配置 .env, 如何 seed database
